# Scaul1.github.io
I have completed a portfolio that contains information on some of my favourite projects I've done this semester as well as my plans for the future. 

Here is the link for my Portfolio:
https://scaul1.github.io/startbootstrap-1-col-portfolio-gh-pages/index.html#  
